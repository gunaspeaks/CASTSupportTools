﻿using Cst.BusinessCore.Helpers;
using Cst.BusinessProcessor.Onboarding;
using Cst.BusinessUtilities.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastReportingService
{
    public class BulkUpdateServiceHelper : IDisposable
    {
        private OnboardingBusinessProcessor buzHelper = null;

        public BulkUpdateServiceHelper()
        {
            CacheHelper.LoadApplicationCache();
            buzHelper = new OnboardingBusinessProcessor();
        }

        public void Dispose()
        {
            buzHelper.Dispose();
        }

        public void ProcessFileForApplicationDetailsBulkInsert(string filePath)
        {
            try
            {
                string fileContent = FilesAndFoldersProcessor.GetFileContent(filePath);
                string[] seperator = new string[] { Environment.NewLine };
                string[] lineItems = fileContent.Split(seperator, StringSplitOptions.None);
                DateTime onboardedDate=new DateTime(2015,1,1);
                foreach(string item in lineItems)
                {
                    string[] fields = item.Split('_');
                    string painArea = string.Format("Row No: {0}", fields[0].Trim());
                    int buID = Convert.ToInt16(fields[1].Trim());
                    int accountID = Convert.ToInt16(fields[2].Trim());
                    string applicationName = fields[3].Trim();
                    int statusID = Convert.ToInt16(fields[4].Trim());
                    string projectID = fields[5].Trim();
                    string managerID = fields[6].Trim();
                    buzHelper.AddNewApplicationForBulkInsert(projectID, managerID, buID, accountID, statusID, onboardedDate, painArea, applicationName);
                }
                
            }
            catch(Exception)
            {

            }
        }
    }
}
