﻿using Cst.BusinessProcessor.Onboarding;
using Cst.BusinessUtilities.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CastReportingService
{
    public class ReportingServiceHelper : IDisposable
    {
        private OnboardingBusinessProcessor buzHelper = null;
        private string smtpIPAddress = null;

        public ReportingServiceHelper()
        {
            CacheHelper.LoadApplicationCache();
            buzHelper = new OnboardingBusinessProcessor();
            smtpIPAddress = CacheHelper.GetSystemSettingByName(SystemSettingConstants.SMTP_CLIENT_IP_ADDRESS);
        }

        public void SendPeriodicCastExecutionReport()
        {
            //DateTime currentDate = new DateTime(2016, 11, 15);
            DateTime currentDate = DateTime.Now;
            DateTime startDate = currentDate, endDate = currentDate;
            LoggingHelper.LogMessage("*************************************************************************");
            LoggingHelper.LogMessage(String.Format("Execution date {0}", currentDate));
            LoggingHelper.LogMessage(String.Format("Execution Day {0}", currentDate.DayOfWeek));
            ReportingPeriod identifiedReportingPeriod = ReportingPeriod.None;

            // Determine whether weekly report can be sent
            if (currentDate.DayOfWeek == DayOfWeek.Monday)
            {
                identifiedReportingPeriod = ReportingPeriod.Weekly;
                endDate = currentDate.AddDays(-1);
                startDate = currentDate.AddDays(-7);
                buzHelper.SendPeriodicCastExecutionReport(identifiedReportingPeriod, startDate, endDate, CacheHelper.GetSystemSettingByName(SystemSettingConstants.WEB_APPLICATION_URL), CacheHelper.GetSystemSettingByName(SystemSettingConstants.TEMPLATES_PATH), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SMTP_CLIENT_IP_ADDRESS), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SYSTEM_OWNERE_MAIL_ID));
            }

            // Determin whether monthly report can be sent
            if (currentDate.Day == 1)
            {
                identifiedReportingPeriod = ReportingPeriod.Monthly;
                int monthNo = Thread.CurrentThread.CurrentUICulture.Calendar.GetMonth(currentDate);
                int noOfDays = Thread.CurrentThread.CurrentUICulture.Calendar.GetDaysInMonth(currentDate.Year, monthNo);
                startDate = new DateTime(currentDate.Year, monthNo, 1).AddMonths(-1);
                endDate = new DateTime(currentDate.Year, monthNo, noOfDays).AddMonths(-1);
                buzHelper.SendPeriodicCastExecutionReport(identifiedReportingPeriod, startDate, endDate, CacheHelper.GetSystemSettingByName(SystemSettingConstants.WEB_APPLICATION_URL), CacheHelper.GetSystemSettingByName(SystemSettingConstants.TEMPLATES_PATH), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SMTP_CLIENT_IP_ADDRESS), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SYSTEM_OWNERE_MAIL_ID));
                buzHelper.SendMonthlyExecutionSummary(CacheHelper.GetSystemSettingByName(SystemSettingConstants.TEMPLATES_PATH), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SMTP_CLIENT_IP_ADDRESS), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SYSTEM_OWNERE_MAIL_ID));
            }

            if (currentDate.Day == 15)
            {
                buzHelper.SendMonthlyExecutionSummary(CacheHelper.GetSystemSettingByName(SystemSettingConstants.TEMPLATES_PATH), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SMTP_CLIENT_IP_ADDRESS), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SYSTEM_OWNERE_MAIL_ID));
            }

            // determine whether quarterly report can be sent
            if (currentDate.Day == 1 && (currentDate.Month == 1 || currentDate.Month == 4 || currentDate.Month == 7 || currentDate.Month == 9))
            {
                identifiedReportingPeriod = ReportingPeriod.Quaterly;
                startDate = new DateTime(currentDate.Year, currentDate.Month, 1).AddMonths(-3);
                endDate = currentDate.AddDays(-1);
                buzHelper.SendPeriodicCastExecutionReport(identifiedReportingPeriod, startDate, endDate, CacheHelper.GetSystemSettingByName(SystemSettingConstants.WEB_APPLICATION_URL), CacheHelper.GetSystemSettingByName(SystemSettingConstants.TEMPLATES_PATH), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SMTP_CLIENT_IP_ADDRESS), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SYSTEM_OWNERE_MAIL_ID));
            }

            // determine whether half yearly report can be sent
            if (currentDate.Day == 1 && (currentDate.Month == 1 || currentDate.Month == 7))
            {
                identifiedReportingPeriod = ReportingPeriod.HalfYearly;
                startDate = new DateTime(currentDate.Year, currentDate.Month, 1).AddMonths(-6);
                endDate = currentDate.AddDays(-1);
                buzHelper.SendPeriodicCastExecutionReport(identifiedReportingPeriod, startDate, endDate, CacheHelper.GetSystemSettingByName(SystemSettingConstants.WEB_APPLICATION_URL), CacheHelper.GetSystemSettingByName(SystemSettingConstants.TEMPLATES_PATH), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SMTP_CLIENT_IP_ADDRESS), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SYSTEM_OWNERE_MAIL_ID));
            }

            // determine yearly report can be sent
            if (currentDate.Day == 1 && currentDate.Month == 1 & currentDate.Year == DateTime.Now.Year)
            {
                identifiedReportingPeriod = ReportingPeriod.Yearly;
                startDate = new DateTime(currentDate.Year - 1, 1, 1);
                endDate = new DateTime(currentDate.Year - 1, 12, Thread.CurrentThread.CurrentUICulture.Calendar.GetDaysInMonth(currentDate.Year - 1, 12));
                buzHelper.SendPeriodicCastExecutionReport(identifiedReportingPeriod, startDate, endDate, CacheHelper.GetSystemSettingByName(SystemSettingConstants.WEB_APPLICATION_URL), CacheHelper.GetSystemSettingByName(SystemSettingConstants.TEMPLATES_PATH), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SMTP_CLIENT_IP_ADDRESS), CacheHelper.GetSystemSettingByName(SystemSettingConstants.SYSTEM_OWNERE_MAIL_ID));
            }

            if (identifiedReportingPeriod != ReportingPeriod.None)
            {
                LoggingHelper.LogMessage(string.Format("Preparing to send {0} Report", identifiedReportingPeriod));
            }
            else
            {
                LoggingHelper.LogMessage("No reporting period has been identified. No email will be sent");
            }
        }

        public void SendServiceStopNotification()
        {
            buzHelper.SendServiceStopNotification("CAST - Periodic Reporting Email Service Stopped", "Service is deactivated now", smtpIPAddress);
        }

        public void Dispose()
        {
            buzHelper.Dispose();
        }
    }
}
