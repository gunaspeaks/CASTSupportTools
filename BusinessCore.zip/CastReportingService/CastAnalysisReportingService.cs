﻿using Cst.BusinessUtilities.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace CastReportingService
{
    public partial class CastAnalysisReportingService : ServiceBase
    {
        ReportingServiceHelper serviceHelper = null;
        Timer serviceTimer;

        public CastAnalysisReportingService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                LoggingHelper.LogMessage("Starting Service");
                serviceTimer = new Timer();
                double defaultScheduledMin = 12 * 60 * 60 * 1000;

                if (String.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["serviceTriggerInterval"]) == false)
                {
                    try
                    {
                        defaultScheduledMin = Convert.ToDouble(ConfigurationManager.AppSettings["serviceTriggerInterval"]) * 60 * 60 * 1000;
                    }
                    catch (Exception) { }
                }
                serviceHelper = new ReportingServiceHelper();
                serviceTimer.Interval = defaultScheduledMin;
                serviceTimer.Enabled = true;
                serviceTimer.Start();
                serviceTimer.Elapsed += TimerElapsed;
            }
            catch (Exception exp)
            {
                LoggingHelper.LogMessage("Error has occurred while running the service", exp);
            }
        }

        private void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            LoggingHelper.LogMessage("Service triggered");
            serviceHelper.SendPeriodicCastExecutionReport();
        }

        protected override void OnStop()
        {
            serviceHelper.SendServiceStopNotification();
            LoggingHelper.LogMessage(String.Format("Service stopped by {0}", Environment.UserName));
            serviceTimer.Stop();
            serviceTimer.Dispose();
            serviceHelper.Dispose();
        }
    }
}
