﻿using Cst.BusinessProcessor.Common;
using Cst.BusinessProcessor.Settings;
using Cst.BusinessProcessor.TechSpec;
using Cst.BusinessUtilities.Common;
using Cst.BusinessUtilities.Entities.Common;
using Cst.BusinessUtilities.Entities.Settings;
using Cst.BusinessUtilities.Entities.TechSpec;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CastReportingService
{
    public static class CacheHelper
    {
        public static List<SystemSettingsEntity> SystemSettingsList = null;
        private static ApplicationDataBusinessProcessor appDataProcessor = null;

        static CacheHelper()
        {
            appDataProcessor = new ApplicationDataBusinessProcessor();
        }

        public static void LoadApplicationCache()
        {
            SystemSettingsList = appDataProcessor.GetSystemSettings();
        }

        public static string GetSystemSettingByName(string settingName)
        {
            return (from item in SystemSettingsList where item.SettingsName.Trim() == settingName select item.SettingsValue.Trim()).FirstOrDefault();
        }
    }
}
