﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cat.BusinessCore.Contracts.UserInterface
{
    public interface IToolBarCommands
    {
        #region Toolbar Commands

        bool CanAddNew { get;  }

        bool CanEdit { get;  }

        bool CanSave { get;  }

        bool CanDelete { get;  }

        bool CanExport { get; }

        string DynamicActionName { get; }

        #endregion

        #region Operation Methods

        bool ExecuteAddNewOperation();

        bool ExecuteEditOperation();

        bool ExecuteSaveOperation();

        bool? ExecuteCancelOperation();

        bool ExecuteDeleteOperation();

        void ExecuteRefreshOperation();

        void ExecuteDynamicOperation();

        void ExecuteExportOperation();

        #endregion

        #region Properties

        ApplicationActions CurrentAction { get; set; }

        string SelectedItemId { get; set; }

        #endregion
    }

    public enum ApplicationActions
    {
        PageLoadedAction,
        NewEntryAction,
        EditAction,
        ItemSelectedAction,
        SaveCompletedAction
    }
}
