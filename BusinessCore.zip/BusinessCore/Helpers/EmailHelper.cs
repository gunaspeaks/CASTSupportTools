﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;

namespace Cat.BusinessCore.Helpers
{
    public class EmailHelper
    {
        private string orderPDFFilePath = string.Empty;
        private string pdfFileName = string.Empty;

        public static void SendEmail(string emailClientIp, string fromEmailID, string toEmailID, string emailSubject, string emailBody, string bccEmailId = "")
        {
            SmtpClient smtpClient = null;
            MailMessage orderMail = new MailMessage();
            try
            {
                orderMail.From = new MailAddress(fromEmailID);
                orderMail.To.Add(toEmailID);
                orderMail.Subject = emailSubject;
                orderMail.IsBodyHtml = true;
                orderMail.Body = emailBody;
                if (String.IsNullOrWhiteSpace(bccEmailId) == false) orderMail.Bcc.Add(new MailAddress(fromEmailID));
                smtpClient = new SmtpClient(emailClientIp);
                smtpClient.Send(orderMail);
            }
            catch (Exception exp) { throw exp; }
            finally
            {
                if (smtpClient != null) smtpClient.Dispose();
                orderMail.Dispose();
            }
        }

        public static string GetEmailIDByEmployeeID(string employeeID)
        {
            string emailID = "";
            string ldappUrl = ConfigurationManager.AppSettings["ldapURL"];
            using (DirectoryEntry de = new DirectoryEntry("LDAP://cts.com"))
            {
                using (DirectorySearcher adSearch = new DirectorySearcher(de))
                {
                    adSearch.Filter = string.Format("(sAMAccountName={0})", employeeID);
                    adSearch.PropertiesToLoad.Add("mail");
                    SearchResult adSearchResult = adSearch.FindOne();

                    emailID = adSearchResult.Properties["mail"][0].ToString();
                }
            }
            return emailID;
        }

        private void GetEMailAttachment(string pdfFileName)
        {
            //DirectoryInfo directory = new DirectoryInfo(@"D:\PDFTemp\");
            //if (directory.Exists)
            //{
            //    foreach (FileInfo file in directory.GetFiles())
            //    {
            //        if (file.Name == pdfFileName)
            //        {
            //            orderPDFFilePath = file.FullName;
            //        }
            //    }                
            //}          
        }
    }
}